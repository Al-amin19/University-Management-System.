#!/bin/bash
clear
figlet -f slant -c "UNIVERSITY MANAGEMENT" | lolcat
echo "1. Login"
echo "2. About"
echo "3. Exit"

db="student_database.txt"
teacher_db="teacher_database.txt"
staff_db="staff_database.txt"
advisor_file="advisor_assignments.txt"
schedule_file="schedule.txt"
resource_file="resources.txt"
announcement_file="announcements.txt"
forum_file="discussion_forum.txt"
email_log="email_log.txt"
transport_file="transport.txt" 

admin_username="admin"
admin_password="12345" 

admin_login() {
    echo "Enter Username: "
    read username
    echo "Enter Password: "
    read -s password

    if [ "$username" == "$admin_username" ] && [ "$password" == "$admin_password" ]; then
        echo "Login successful!"
        sleep 1
        return 0
    else
        echo "Invalid username or password. Try again."
        return 1
    fi
}

stud_manage() {
    clear
    while true; do
        figlet -f slant -c "STUDENT MANAGEMENT" | lolcat
        echo "1. View Database"
        echo "2. View Specific Records"
        echo "3. Add Records"
        echo "4. Delete Records"
        echo "5. Go Back"
        echo "Choose an option: "
        read data
        case $data in
            1) 
                [ -f "$db" ] && cat "$db" || echo "No student database found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Student ID: "
                read id
                [ -f "$db" ] && grep -i "$id" "$db" || echo "Record not found."
                echo "Press Enter to continue..."
                read ;;
            3)
                echo "Enter Name: "
                read snm
                echo "Enter ID: "
                read sid
                echo "Enter Department: "
                read sdep
                echo "Enter University: "
                read suni
                echo "$snm | $sid | $sdep | $suni" >> "$db"
                echo "Record added successfully. Press Enter to continue..."
                read ;;
            4)
                echo "Enter ID to delete: "
                read id
                if [ -f "$db" ]; then
                    grep -v "$id" "$db" > tmpfile && mv tmpfile "$db"
                    echo "Record deleted."
                else
                    echo "No student database found."
                fi
                echo "Press Enter to continue..."
                read ;;
            5) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

teacher_manage() {
    clear
    while true; do
        figlet -f slant -c "TEACHER MANAGEMENT" | lolcat
        echo "1. View Database"
        echo "2. Add Records"
        echo "3. Delete Records"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$teacher_db" ] && cat "$teacher_db" || echo "No teacher database found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Name: "
                read name
                echo "Enter ID: "
                read id
                echo "Enter Department: "
                read dep
                echo "Enter University: "
                read uni
                echo "$name | $id | $dep | $uni" >> "$teacher_db"
                echo "Record added successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter ID to delete: "
                read id
                if [ -f "$teacher_db" ]; then
                    grep -v "$id" "$teacher_db" > tmpfile && mv tmpfile "$teacher_db"
                    echo "Record deleted."
                else
                    echo "No teacher database found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

staff_manage() {
    clear
    while true; do
        figlet -f slant -c "STAFF MANAGEMENT" | lolcat
        echo "1. View Database"
        echo "2. Add Records"
        echo "3. Delete Records"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$staff_db" ] && cat "$staff_db" || echo "No staff database found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Name: "
                read name
                echo "Enter ID: "
                read id
                echo "Enter Department: "
                read dep
                echo "Enter University: "
                read uni
                echo "$name | $id | $dep | $uni" >> "$staff_db"
                echo "Record added successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter ID to delete: "
                read id
                if [ -f "$staff_db" ]; then
                    grep -v "$id" "$staff_db" > tmpfile && mv tmpfile "$staff_db"
                    echo "Record deleted."
                else
                    echo "No staff database found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

resource_manage() {
    clear
    while true; do
        figlet -f slant -c "RESOURCE MANAGEMENT" | lolcat
        echo "1. View Resources"
        echo "2. Add Resource"
        echo "3. Delete Resource"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$resource_file" ] && cat "$resource_file" || echo "No resources found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Resource Name(Lab or Library): "
                read name
                echo "Enter Resource details (Available or Unavaiable}: "
                read details
                echo "$name | $details" >> "$resource_file"
                echo "Resource added successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter Resource Name to delete: "
                read name
                if [ -f "$resource_file" ]; then
                    grep -v "$name" "$resource_file" > tmpfile && mv tmpfile "$resource_file"
                    echo "Resource deleted."
                else
                    echo "No resources found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

advisor_monitoring() {
 clear
 while true; do
   figlet -f slant -c "ADVISOR MONITORING" | lolcat
   echo "1. Assign Advisor"
   echo "2. View Assigned Advisors"
   echo "3. Go Back"
   echo "Choose an option: "
   read monitor_choice
   case $monitor_choice in
     1)
       echo "Enter Student ID to assign advisor:"
       read student_id
       if (( student_id % 2 == 0 )); then
         advisor="Teacher A"
       else
         advisor="Teacher B"
       fi
       echo "$student_id is assigned to $advisor."
       echo "$student_id $advisor" >> "$advisor_file"
       echo "Assignment saved. Press Enter to continue..."
       read ;;
     2)
       if [ -f "$advisor_file" ]; then
         echo "Assigned Advisors:"
         cat "$advisor_file"
       else
         echo "No advisor assignments found."
       fi
       echo "Press Enter to continue..."
       read ;;
     3) return ;; 
     *) echo "Invalid option. Try again." ;;
   esac
 done
}
 
scheduling_module() {
 clear
 while true; do
   figlet -f slant -c "SCHEDULING MODULE" | lolcat
   echo "1. Add Timetable Entry"
   echo "2. View Timetable"
   echo "3. Add Exam Schedule"
   echo "4. View Exam Schedules"
   echo "5. Go Back"
   echo "Choose an option: "
   read schedule_choice
   case $schedule_choice in
     1)
       echo "Enter Course Code: "
       read course_code
       echo "Enter Day (e.g., Monday): "
       read day
       echo "Enter Time (e.g., 10:00 AM): "
       read time
       echo "Enter Room Number: "
       read room
       echo "Timetable | $course_code | $day | $time | $room" >> "$schedule_file"
       echo "Timetable entry added. Press Enter to continue..."
       read ;;
     2)
       if [ -f "$schedule_file" ]; then
         echo "Timetable Entries:"
         grep -i "Timetable" "$schedule_file"
       else
         echo "No timetable found."
       fi
       echo "Press Enter to continue..."
       read ;;
     3)
       echo "Enter Course Code: "
       read course_code
       echo "Enter Exam Date (2024-12-01): "
       read exam_date
       echo "Enter Time ( 10:00 AM): "
       read exam_time
       echo "Enter Room Number: "
       read room
       echo "Exam | $course_code |
| $exam_date | $exam_time | $room" >> "$schedule_file"
       echo "Exam schedule added. Press Enter to continue..."
       read ;;
     4)
       if [ -f "$schedule_file" ]; then
         echo "Exam Schedules:"
         grep -i "Exam" "$schedule_file"
       else
         echo "No exam schedules found."
       fi
       echo "Press Enter to continue..."
       read ;;
     5) return ;; 
     *) echo "Invalid option. Try again." ;;
   esac
 done
}

announcements() {
    clear
    while true; do
        figlet -f slant -c "ANNOUNCEMENTS" | lolcat
        echo "1. View Announcements"
        echo "2. Add Announcement"
        echo "3. Delete Announcement"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$announcement_file" ] && cat "$announcement_file" || echo "No announcements found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Announcement: "
                read announcement
                echo "$announcement" >> "$announcement_file"
                echo "Announcement added successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter Announcement to delete: "
                read announcement
                if [ -f "$announcement_file" ]; then
                    grep -v "$announcement" "$announcement_file" > tmpfile && mv tmpfile "$announcement_file"
                    echo "Announcement deleted."
                else
                    echo "No announcements found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

discussion_forum() {
    clear
    while true; do
        figlet -f slant -c "DISCUSSION FORUM" | lolcat
        echo "1. View Forum"
        echo "2. Post Discussion"
        echo "3. Delete Post"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$forum_file" ] && cat "$forum_file" || echo "No discussions found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Your Discussion: "
                read discussion
                echo "$discussion" >> "$forum_file"
                echo "Discussion posted successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter Discussion to delete: "
                read discussion
                if [ -f "$forum_file" ]; then
                    grep -v "$discussion" "$forum_file" > tmpfile && mv tmpfile "$forum_file"
                    echo "Discussion deleted."
                else
                    echo "No discussions found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

view_summary() {
    clear
    figlet -f slant -c "SUMMARY" | lolcat
    total_students=$(wc -l < "$db" 2>/dev/null || echo 0)
    total_teachers=$(wc -l < "$teacher_db" 2>/dev/null || echo 0)
    total_staff=$(wc -l < "$staff_db" 2>/dev/null || echo 0)
    total_resources=$(wc -l < "$resource_file" 2>/dev/null || echo 0)
    total_advisors=$(wc -l < "$advisor_file" 2>/dev/null || echo 0)
    total_schedule=$(wc -l < "$schedule_file" 2>/dev/null || echo 0)
    total_transport=$(wc -l < "$transport_file" 2>/dev/null || echo 0) 
    echo "Total number of students: $total_students"
    echo "Total number of teachers: $total_teachers"
    echo "Total number of staff: $total_staff"
    echo "Total resources available: $total_resources"
    echo "Total advisor assignments: $total_advisors"
    echo "Total schedules: $total_schedule"
    echo "Total transport records: $total_transport"  
    echo "Press Enter to continue..."
    read
}

transport_management() {
    clear
    while true; do
        figlet -f slant -c "TRANSPORT MANAGEMENT" | lolcat
        echo "1. View Transport Records"
        echo "2. Add Transport Record"
        echo "3. Delete Transport Record"
        echo "4. Go Back"
        echo "Choose an option: "
        read choice
        case $choice in
            1)
                [ -f "$transport_file" ] && cat "$transport_file" || echo "No transport records found."
                echo "Press Enter to continue..."
                read ;;
            2)
                echo "Enter Bus Name: "
                read bus_name
                echo "Enter Bus Schedule: "
                read bus_schedule
                echo "Enter Bus Location: "
                read bus_location
                echo "$bus_name | $bus_schedule | $bus_location" >> "$transport_file"
                echo "Transport record added successfully. Press Enter to continue..."
                read ;;
            3)
                echo "Enter Bus Name to delete: "
                read bus_name
                if [ -f "$transport_file" ]; then
                    grep -v "$bus_name" "$transport_file" > tmpfile && mv tmpfile "$transport_file"
                    echo "Transport record deleted."
                else
                    echo "No transport records found."
                fi
                echo "Press Enter to continue..."
                read ;;
            4) return ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

logout() {
    clear
    echo "Logging out..."
    sleep 1
    exit 0
}

main_menu() {
    clear
    while true; do
        figlet -f slant -c "MAIN MENU" | lolcat
        echo "1. Manage Students"
        echo "2. Manage Teachers"
        echo "3. Manage Staff"
        echo "4. Manage Resources"
        echo "5. View Summary"
        echo "6. Advisor Monitoring"
        echo "7. Scheduling Module"
        echo "8. Announcements"
        echo "9. Discussion Forum"
        echo "10. Transport Management" 
        echo "11. Logout"
        echo "Choose an option: "
        read manage_choice
        case $manage_choice in
            1) stud_manage ;;
            2) teacher_manage ;;
            3) staff_manage ;;
            4) resource_manage ;;
            5) view_summary ;;
            6) advisor_monitoring ;;
            7) scheduling_module ;;
            8) announcements ;;
            9) discussion_forum ;;
            10) transport_management ;; 
            11) logout ;;
            *) echo "Invalid option. Try again." ;;
        esac
    done
}

echo "Choice an option:"
read choice
if [ "$choice" -eq 1 ]; then
    figlet -f slant -c "Login" | lolcat
    echo "Enter Username:"
    read user
    echo "Enter Password:"
    read pass
    if [ "$user" == "admin" ] && [ "$pass" == "12345" ]; then
       echo "Login Success!"
       echo "Enter database path or name for student records: "
       read db
       echo "Enter database path or name for teacher records: "
       read teacher_db
       echo "Enter database path or name for staff records: "
       read staff_db

       touch "$db" "$teacher_db" "$staff_db" "$advisor_file" "$schedule_file" "$resource_file"
main_menu
    else
       echo "Login failed!"
    fi
elif [ "$choice" -eq 2 ]; then
    figlet -f slant -c "ABOUT" | lolcat
    echo "University Management System by SAJKR"
    echo "This is our first project in os"
    echo "Press Enter to return to the main menu..."
    read
    exec "$0"
else
    exit
fi

